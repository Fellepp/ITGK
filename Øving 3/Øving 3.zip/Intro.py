#a)
for i in range(1,6):
    print(i)

#b)
i=1
while i<=5:
    print(i)
    i+=1
