Python 3.6.2 (v3.6.2:5fd33b5, Jul  8 2017, 04:14:34) [MSC v.1900 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> x = 1
>>> y = 2
>>> z = x+y
>>> myString = input("Skriv in tekst: ")
Skriv in tekst: 
>>> myNum = int(input("Skriv inn et heltall: "))
Skriv inn et heltall: 5
>>> print("Du skrev dette: ",myString, myNum, "og x + y =", z)
Du skrev dette:   5 og x + y = 3
>>> print(12*'na '+'bat'+'man')
na na na na na na na na na na na na batman
>>> 
