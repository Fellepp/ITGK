r = 5
print("Vi har en sirkel med radius", r)
omkrets = 2 * 3.14 * r
print("Omkretsen er", omkrets)
areal = 3.14 * r ** 2
print("Arealet er", areal)
h = 8
volum = areal * h
print("Sylinder med høyde", h, ": Volumet er", volum)
