#d)
print("hello world")
#e)
tall1 = int(input("Tall 1: "))
tall2 = int(input("Tall 2: "))
sum = tall1+tall2
print(tall1, "+", tall2, "=", sum)
#f)
tall3 = int(input("Tall 3: "))
tall4 = int(input("Tall 4: "))
modulo = tall3%tall4
print(tall3, "modulo", tall4, "=", modulo)
#g)
#Dette er en kommentar
