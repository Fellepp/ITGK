#MITT NAVN
#a)
navn = "Filip Johansen"
print("Mitt navn er", navn)
#b)
navn = "Filip Johansen"
alder = 20
print("Mitt navn er", navn, "og jeg er", alder, "år gammel")
#c)
navn = input("Skriv inn ditt navn: ")
velkomst = "Hei, " + navn + ", hvor gammel er du?"
alder = int(input(velkomst))
prog_ald = int(input("Hvor gammel var du da du begynte å programmere?"))
regning = alder - prog_ald
print("Da har du programmert i", regning, "år")


