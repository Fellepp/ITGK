#a)
my_first_list = [1,2,3,4,5,6]
#b)
print(my_first_list[5])
#c)
my_first_list[4] = 'pluss'
#d)
my_second_list = [my_first_list[3], my_first_list[4], my_first_list[5]]
#e)
print(my_second_list, " er lik 10")
