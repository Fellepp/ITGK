def boardMaker():
    matrix = [[[] for i in range(3)] for i in range(3)]
    boardPrinter(matrix)
    for i in range(3):
        for j in range(3):
            number = input("Please enter x or o : ")
            matrix[i][j] = number
    boardPrinter(matrix)

def boardPrinter(board):
    for i in range(0, len(board)):
        print(board[i])

def vinner(board):


boardMaker()